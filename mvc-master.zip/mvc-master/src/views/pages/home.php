<?php $render('header'); ?>

Opa, <?=$nome;?>